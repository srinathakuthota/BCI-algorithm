"""Aggregate all real runs into results/summary.json + figures (Dataset 2a, sessions A01T-A09T)."""
import glob, json
import numpy as np, pandas as pd
from scipy import stats
from sklearn.metrics import precision_recall_fscore_support
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

R = "/home/claude/results"
CLASSES = ["Left hand", "Right hand", "Feet", "Tongue"]
MODELS = ["dual", "fbcsp_only", "conv_only", "svm", "knn", "lstm", "eegnet"]

def load(protocol):
    if protocol == "subject":
        df = pd.read_csv(f"{R}/2a_subject_runs_merged.csv")
    elif protocol == "pooled":
        df = pd.read_csv(f"{R}/2a_pooled_runs.csv")
    elif protocol == "session":
        df = pd.read_csv("/home/claude/results_session/2a_session_runs.csv")
    else:
        df = pd.concat([pd.read_csv(f) for f in sorted(glob.glob("/home/claude/results_loso/S*/2a_loso_runs.csv"))])
    return df

def per_subject(df):
    d = df[df.subject != "ALL"].copy(); d["subject"] = d.subject.astype(int)
    return d.groupby(["model", "condition", "subject"]).acc.agg(["mean", "std", "count"]).reset_index()

def wilcox(ps, a, b, cond="clean"):
    x = ps[(ps.model == a) & (ps.condition == cond)].set_index("subject")["mean"]
    y = ps[(ps.model == b) & (ps.condition == cond)].set_index("subject")["mean"]
    j = x.index.intersection(y.index)
    if len(j) < 5: return None
    w = stats.wilcoxon(x[j], y[j])
    return dict(n=len(j), diff=float((x[j] - y[j]).mean()), p=float(w.pvalue))

S = {}
for proto in ["subject", "session", "pooled", "loso"]:
    try:
        df = load(proto)
    except Exception as e:
        print("skip", proto, e); continue
    ps = per_subject(df)
    out = {"per_subject": {}, "overall": {}, "wilcoxon": {}, "n_subjects": int(ps.subject.nunique())}
    for (m, c), g in ps.groupby(["model", "condition"]):
        out["per_subject"][f"{m}|{c}"] = {int(r.subject): [round(r["mean"], 1), None if np.isnan(r["std"]) else round(r["std"], 1)] for _, r in g.iterrows()}
        if proto == "pooled":
            a = df[(df.subject == "ALL") & (df.model == m) & (df.condition == c)].acc
            out["overall"][f"{m}|{c}"] = dict(mean=round(a.mean(), 2), sd=round(a.std(ddof=1), 2), n_runs=int(len(a)),
                                             ci95=round(1.96 * a.std(ddof=1) / np.sqrt(len(a)), 2))
        else:
            out["overall"][f"{m}|{c}"] = dict(mean=round(g["mean"].mean(), 2), sd=round(g["mean"].std(ddof=1), 2), n_subjects=int(len(g)))
    for m in MODELS[1:]:
        r = wilcox(ps, "dual", m)
        if r: out["wilcoxon"][f"dual_vs_{m}"] = r
    r = wilcox(ps, "dual", "fbcsp_only", "awgn5dB")
    if r: out["wilcoxon"]["dual_vs_fbcsp_only|awgn5dB"] = r
    r = wilcox(ps, "dual", "conv_only", "awgn5dB")
    if r: out["wilcoxon"]["dual_vs_conv_only|awgn5dB"] = r
    S[proto] = out

# confusion matrices (pooled): split0/seed0 dual, and sum over all dual runs
cms = json.load(open(f"{R}/2a_pooled_confusion.json"))
def cm_block(model):
    first = [c for c in cms if c["model"] == model and c["split"] == "split0" and c["seed"] == 0 and c["condition"] == "clean"][0]
    tot = np.sum([np.array(c["cm"]) for c in cms if c["model"] == model and c["condition"] == "clean"], axis=0)
    def prf(cm):
        cm = np.array(cm); y = np.repeat(np.arange(4), cm.sum(1)); yp = np.concatenate([np.repeat(np.arange(4), r) for r in cm])
        p, r, f, s = precision_recall_fscore_support(y, yp, zero_division=0)
        return dict(precision=p.round(3).tolist(), recall=r.round(3).tolist(), f1=f.round(3).tolist(), support=s.tolist(),
                    acc=round(100 * np.trace(cm) / cm.sum(), 2), n=int(cm.sum()))
    return dict(first=first["cm"], first_metrics=prf(first["cm"]), summed=tot.tolist(), summed_metrics=prf(tot))
S["confusion"] = {m: cm_block(m) for m in ["dual", "fbcsp_only"]}
S["leakage"] = pd.read_csv(f"{R}/2a_leakage_diagnostic.csv").to_dict("records")
json.dump(S, open(f"{R}/summary.json", "w"), indent=1)

# ---------------- figures
plt.rcParams.update({"font.family": "serif", "font.size": 10})
LBL = {"dual": "Dual-branch", "fbcsp_only": "FBCSP-only", "conv_only": "Conv1D-only", "svm": "SVM", "knn": "k-NN", "lstm": "LSTM", "eegnet": "EEGNet"}
protos = [p for p in ["subject", "session", "pooled", "loso"] if p in S]
names = {"subject": "Per-subject\n(within-session)", "session": "Per-subject\n(T → E)", "pooled": "Pooled\n(subject-overlapping)", "loso": "LOSO\n(cross-subject)"}
fig, ax = plt.subplots(figsize=(7.5, 3.4))
w = 0.26; cols = {"fbcsp_only": "#4C72B0", "conv_only": "#DD8452", "dual": "#55A868"}
for i, m in enumerate(["fbcsp_only", "conv_only", "dual"]):
    mu = [S[p]["overall"][f"{m}|clean"]["mean"] for p in protos]; sd = [S[p]["overall"][f"{m}|clean"]["sd"] for p in protos]
    ax.bar(np.arange(len(protos)) + (i - 1) * w, mu, w, yerr=sd, capsize=3, label=LBL[m], color=cols[m])
ax.axhline(25, ls="--", c="grey", lw=0.8); ax.text(len(protos) - 0.55, 26, "chance", fontsize=8, color="grey")
ax.set_xticks(range(len(protos))); ax.set_xticklabels([names[p] for p in protos]); ax.set_ylabel("Accuracy (%)"); ax.set_ylim(0, 90)
ax.legend(frameon=False, ncol=3, loc="upper right"); ax.set_title("Branch ablation, BCI IV-2a (mean ± SD)")
fig.tight_layout(); fig.savefig(f"{R}/fig_ablation.png", dpi=200)

fig, ax = plt.subplots(figsize=(6.5, 3.2))
ms = ["fbcsp_only", "conv_only", "dual", "svm"]; x = np.arange(len(ms))
for j, (c, col) in enumerate([("clean", "#4C72B0"), ("awgn5dB", "#C44E52")]):
    mu = [S["pooled"]["overall"][f"{m}|{c}"]["mean"] for m in ms]; sd = [S["pooled"]["overall"][f"{m}|{c}"]["sd"] for m in ms]
    ax.bar(x + (j - 0.5) * 0.36, mu, 0.36, yerr=sd, capsize=3, color=col, label="Clean" if c == "clean" else "5 dB AWGN")
ax.axhline(25, ls="--", c="grey", lw=0.8)
ax.set_xticks(x); ax.set_xticklabels([LBL[m] for m in ms]); ax.set_ylabel("Accuracy (%)"); ax.set_ylim(0, 70); ax.legend(frameon=False)
ax.set_title("Noise stress test, pooled protocol, BCI IV-2a"); fig.tight_layout(); fig.savefig(f"{R}/fig_noise.png", dpi=200)

if "loso" in S:
    fig, ax = plt.subplots(figsize=(7, 3.2)); subs = sorted(S["loso"]["per_subject"]["dual|clean"].keys())
    for i, m in enumerate(["fbcsp_only", "dual", "eegnet"]):
        v = [S["loso"]["per_subject"][f"{m}|clean"].get(s, [np.nan])[0] for s in subs]
        ax.bar(np.arange(len(subs)) + (i - 1) * 0.26, v, 0.26, label=LBL[m])
    ax.axhline(25, ls="--", c="grey", lw=0.8); ax.set_xticks(range(len(subs))); ax.set_xticklabels([f"S{s}" for s in subs])
    ax.set_ylabel("Accuracy (%)"); ax.legend(frameon=False, ncol=3); ax.set_title("LOSO accuracy per held-out subject, BCI IV-2a")
    fig.tight_layout(); fig.savefig(f"{R}/fig_loso.png", dpi=200)
print(json.dumps({p: S[p]["overall"] for p in protos}, indent=0)[:3000])
print(json.dumps({p: S[p]["wilcoxon"] for p in protos}, indent=0))
print(S["confusion"]["dual"]["first_metrics"], S["confusion"]["dual"]["summed_metrics"]["acc"])
