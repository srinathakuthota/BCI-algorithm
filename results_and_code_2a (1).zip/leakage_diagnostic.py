"""Which evaluation mistakes would be needed to reach ~98% on pooled 2a? (diagnostic, SVM on FBCSP)"""
import sys, numpy as np, pandas as pd
sys.argv=['x']; import revision_experiments as R
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.svm import SVC
NPZ=sys.argv_npz if hasattr(sys,'argv_npz') else '/tmp/claude-0/-home-claude/0b621708-56e6-5808-b11f-b2775e8151bc/scratchpad/data/bcidatasetIV2a'
D=R.load_npz_2a(NPZ)
strat=np.array([f"{s}_{c}" for s,c in zip(D['subject'],D['y'])])
tr,te=next(StratifiedShuffleSplit(1,test_size=0.2,random_state=0).split(strat,strat))
cfg=dict(m=2,k=20); rows=[]
def add(n,v):
    rows.append((n,v)); print(f'{v:6.1f}%  {n}', flush=True)
# A: correct (fit on training partition only)
Ztr,Zte,Ftr,Fte,*_=R.prepare(D['eeg'][tr],D['eog'][tr],D['eeg'][te],D['eog'][te],D['y'][tr],cfg)
add('A: CSP/MIBIF/scaler fitted on training partition only', 100*(SVC().fit(Ftr,D['y'][tr]).predict(Fte)==D['y'][te]).mean())
# B: CSP + MIBIF fitted on ALL trials (incl. test labels) before splitting
eo=R.EOGRegression().fit(D['eeg'],D['eog']); X=eo.transform(D['eeg'],D['eog'])
fb=R.FBCSP(**cfg).fit(X,D['y']); F=fb.transform(X)
add('B: CSP + MIBIF fitted on all trials before split', 100*(SVC().fit(F[tr],D['y'][tr]).predict(F[te])==D['y'][te]).mean())
# C: overlapping crops of the same trial split randomly (crop-level split), correct fitting otherwise
shifts=[0,25,50,75,100]   # 0-0.4 s shifts; trial window extended to 2.4 s available? use within-epoch crops of 400 samples
Xc=[];Ec=[];yc=[];gc=[]
for i in range(len(D['y'])):
    for s in shifts:
        Xc.append(D['eeg'][i][:,s:s+400]); Ec.append(D['eog'][i][:,s:s+400]); yc.append(D['y'][i]); gc.append(i)
Xc=np.array(Xc);Ec=np.array(Ec);yc=np.array(yc)
R.N_T=400
trc,tec=next(StratifiedShuffleSplit(1,test_size=0.2,random_state=0).split(yc,yc))
_,_,Ftr,Fte,*_=R.prepare(Xc[trc],Ec[trc],Xc[tec],Ec[tec],yc[trc],cfg)
add('C: 5 overlapping crops/trial, split at crop level', 100*(SVC().fit(Ftr,yc[trc]).predict(Fte)==yc[tec]).mean())
for r in rows: print(f"{r[1]:6.1f}%  {r[0]}")
pd.DataFrame(rows,columns=['scenario','acc']).to_csv('results/2a_leakage_diagnostic.csv',index=False)
