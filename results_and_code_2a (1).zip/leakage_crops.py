"""Diagnostic C: overlapping crops of the same trial split at crop level vs trial level (dual-branch net)."""
import sys, numpy as np, pandas as pd
sys.argv = ['x']; import revision_experiments as R
from sklearn.model_selection import StratifiedShuffleSplit, GroupShuffleSplit
NPZ = '/tmp/claude-0/-home-claude/0b621708-56e6-5808-b11f-b2775e8151bc/scratchpad/data/bcidatasetIV2a'
D = R.load_npz_2a(NPZ)
L, shifts = 400, [0, 50, 100]                        # 1.6 s crops, 0.2 s stride, 3 per trial
X = np.concatenate([D['eeg'][:, :, s:s + L] for s in shifts]).astype(np.float32)
E = np.concatenate([D['eog'][:, :, s:s + L] for s in shifts]).astype(np.float32)
y = np.tile(D['y'], len(shifts)); g = np.tile(np.arange(len(D['y'])), len(shifts))
del D
R.N_T = L
rows = []
for name, (tr, te) in [("crop-level random split (crops of one trial in both sets)",
                         next(StratifiedShuffleSplit(1, test_size=0.2, random_state=0).split(y, y))),
                        ("trial-level split (all crops of a trial in one set)",
                         next(GroupShuffleSplit(1, test_size=0.2, random_state=0).split(y, y, g)))]:
    Ztr, Zte, Ftr, Fte, *_ = R.prepare(X[tr], E[tr], X[te], E[te], y[tr], dict(m=2, k=20))
    for m in ["dual", "fbcsp_only"]:
        R._tf().keras.backend.clear_session()
        p, _ = R.fit_predict(m, Ztr, Ftr, y[tr], Zte, Fte, 4, 0, R.HP_GRID[m][0], 100)
        acc = 100 * (p == y[te]).mean(); rows.append((name, m, acc)); print(f"{acc:5.1f}%  {m:10s} {name}", flush=True)
    del Ztr, Zte
pd.DataFrame(rows, columns=["split", "model", "acc"]).to_csv("/home/claude/results/2a_leakage_crops.csv", index=False)
