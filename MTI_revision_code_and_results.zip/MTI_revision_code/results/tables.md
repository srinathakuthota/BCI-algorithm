
### Pooled within-session protocol — Dataset 2a (train 2073 / test 519 trials, mean ± SD over seeds)

| Model | runs (seeds) | Accuracy (%) | Kappa | Precision | Recall | F1 |
|---|---|---|---|---|---|---|
| Dual-branch (FBCSP + Conv1D) | 5 | 46.67 ± 0.79 | 0.289 ± 0.010 | 0.469 ± 0.006 | 0.466 ± 0.008 | 0.457 ± 0.009 |
| Conv1D branch only (ablation) | 5 | 30.10 ± 2.96 | 0.068 ± 0.039 | 0.327 ± 0.004 | 0.301 ± 0.029 | 0.274 ± 0.044 |
| FBCSP branch only (ablation) | 5 | 53.33 ± 2.17 | 0.378 ± 0.029 | 0.538 ± 0.025 | 0.533 ± 0.022 | 0.531 ± 0.022 |
| EEGNet-8,2 (re-implemented) | 1 | 56.84 | 0.424 | 0.585 | 0.568 | 0.566 |
| CNN (ShallowConvNet) | 1 | 47.59 | 0.301 | 0.509 | 0.476 | 0.476 |
| LSTM | 1 | 28.71 | 0.049 | 0.287 | 0.287 | 0.271 |
| FBCSP + SVM (RBF) | 5 | 55.49 ± 2.10 | 0.407 ± 0.028 | 0.558 ± 0.024 | 0.555 ± 0.021 | 0.554 ± 0.022 |
| FBCSP + k-NN | 5 | 53.22 ± 1.43 | 0.376 ± 0.019 | 0.536 ± 0.016 | 0.532 ± 0.014 | 0.531 ± 0.015 |
| FBCSP + LDA | 5 | 49.21 ± 1.81 | 0.323 ± 0.024 | 0.492 ± 0.018 | 0.492 ± 0.018 | 0.491 ± 0.018 |

### Pooled protocol — per-subject accuracy (%) on the held-out 20 % test trials, Dataset 2a (mean over seeds)

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | CNN (ShallowConvNet) | LSTM | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 57.1 | 31.8 | 59.5 | 62.7 | 42.4 | 32.2 | 63.3 | 61.6 | 51.2 |
| S2 | 34.0 | 29.6 | 37.1 | 31.0 | 41.4 | 25.9 | 32.7 | 35.0 | 32.0 |
| S3 | 59.2 | 35.2 | 69.1 | 71.9 | 56.1 | 28.1 | 73.2 | 69.5 | 66.8 |
| S4 | 41.3 | 24.1 | 42.0 | 49.1 | 42.1 | 19.3 | 45.1 | 39.2 | 43.0 |
| S5 | 31.6 | 24.3 | 40.0 | 41.4 | 34.5 | 24.1 | 40.7 | 38.2 | 35.4 |
| S6 | 31.5 | 30.1 | 30.8 | 41.4 | 37.9 | 22.4 | 37.3 | 35.6 | 30.5 |
| S7 | 43.1 | 24.7 | 51.9 | 62.7 | 44.1 | 23.7 | 58.5 | 56.4 | 43.2 |
| S8 | 63.9 | 36.4 | 79.7 | 76.8 | 64.3 | 48.2 | 78.7 | 76.6 | 71.4 |
| S9 | 58.2 | 34.5 | 70.1 | 75.4 | 66.7 | 35.1 | 70.0 | 66.9 | 69.7 |
| Mean ± SD | 46.7 ± 13.0 | 30.1 ± 4.8 | 53.3 ± 17.1 | 56.9 ± 16.7 | 47.7 ± 11.7 | 28.8 ± 8.8 | 55.5 ± 17.0 | 53.2 ± 16.3 | 49.2 ± 16.3 |

### Confusion matrix, dual-branch, pooled protocol, Dataset 2a (seed 0 test partition, n = 519)

| Actual \ Pred. | Left hand | Right hand | Feet | Tongue |
|---|---|---|---|---|
| Left hand | 57 | 32 | 20 | 21 |
| Right hand | 18 | 74 | 18 | 20 |
| Feet | 23 | 21 | 41 | 45 |
| Tongue | 17 | 19 | 20 | 73 |

### Class-wise performance, dual-branch, pooled, Dataset 2a (seed 0 test partition)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Left hand | 0.496 | 0.438 | 0.465 | 130 |
| Right hand | 0.507 | 0.569 | 0.536 | 130 |
| Feet | 0.414 | 0.315 | 0.358 | 130 |
| Tongue | 0.459 | 0.566 | 0.507 | 129 |

### Confusion matrix, dual-branch, pooled protocol, Dataset 2a (summed over 5 seeds, n = 2595)

| Actual \ Pred. | Left hand | Right hand | Feet | Tongue |
|---|---|---|---|---|
| Left hand | 347 | 166 | 60 | 77 |
| Right hand | 116 | 385 | 64 | 86 |
| Feet | 149 | 133 | 187 | 175 |
| Tongue | 118 | 125 | 115 | 292 |

### Class-wise performance, dual-branch, pooled, Dataset 2a (summed over 5 seeds)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Left hand | 0.475 | 0.534 | 0.503 | 650 |
| Right hand | 0.476 | 0.591 | 0.527 | 651 |
| Feet | 0.439 | 0.290 | 0.350 | 644 |
| Tongue | 0.463 | 0.449 | 0.456 | 650 |

### Pooled within-session protocol — Dataset 2b (train 5216 / test 1304 trials, mean ± SD over seeds)

| Model | runs (seeds) | Accuracy (%) | Kappa | Precision | Recall | F1 |
|---|---|---|---|---|---|---|
| Dual-branch (FBCSP + Conv1D) | 5 | 70.98 ± 1.06 | 0.420 ± 0.021 | 0.712 ± 0.011 | 0.710 ± 0.011 | 0.709 ± 0.011 |
| Conv1D branch only (ablation) | 5 | 69.45 ± 0.67 | 0.389 ± 0.013 | 0.702 ± 0.010 | 0.694 ± 0.007 | 0.692 ± 0.010 |
| FBCSP branch only (ablation) | 5 | 70.48 ± 1.08 | 0.410 ± 0.022 | 0.713 ± 0.011 | 0.705 ± 0.011 | 0.702 ± 0.012 |
| EEGNet-8,2 (re-implemented) | 1 | 73.77 | 0.475 | 0.740 | 0.738 | 0.737 |
| CNN (ShallowConvNet) | 1 | 73.39 | 0.468 | 0.734 | 0.734 | 0.734 |
| LSTM | 1 | 71.09 | 0.422 | 0.711 | 0.711 | 0.711 |
| FBCSP + SVM (RBF) | 5 | 71.78 ± 1.51 | 0.436 ± 0.030 | 0.720 ± 0.016 | 0.718 ± 0.015 | 0.717 ± 0.015 |
| FBCSP + k-NN | 5 | 69.82 ± 0.96 | 0.396 ± 0.019 | 0.700 ± 0.010 | 0.698 ± 0.010 | 0.698 ± 0.010 |
| FBCSP + LDA | 5 | 70.72 ± 1.21 | 0.414 ± 0.024 | 0.707 ± 0.012 | 0.707 ± 0.012 | 0.707 ± 0.012 |

### Pooled protocol — per-subject accuracy (%) on the held-out 20 % test trials, Dataset 2b (mean over seeds)

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | CNN (ShallowConvNet) | LSTM | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 69.3 | 65.4 | 68.5 | 64.6 | 67.4 | 67.4 | 69.0 | 69.0 | 68.3 |
| S2 | 59.4 | 58.8 | 56.5 | 61.8 | 59.6 | 55.9 | 57.6 | 56.3 | 56.5 |
| S3 | 56.8 | 58.1 | 54.3 | 54.9 | 56.9 | 54.9 | 57.8 | 54.6 | 59.7 |
| S4 | 85.5 | 88.6 | 87.8 | 89.2 | 90.5 | 96.6 | 89.1 | 87.7 | 83.5 |
| S5 | 76.8 | 68.5 | 75.7 | 74.3 | 79.1 | 68.2 | 76.4 | 75.4 | 78.0 |
| S6 | 72.5 | 66.5 | 74.2 | 84.0 | 75.0 | 72.9 | 76.0 | 70.7 | 75.1 |
| S7 | 67.8 | 69.2 | 68.8 | 78.5 | 75.0 | 73.6 | 70.8 | 69.0 | 67.2 |
| S8 | 72.4 | 74.2 | 69.2 | 78.9 | 79.6 | 72.4 | 69.3 | 69.3 | 68.8 |
| S9 | 77.1 | 74.3 | 78.1 | 76.4 | 75.7 | 76.4 | 78.8 | 74.9 | 78.1 |
| Mean ± SD | 70.8 ± 8.9 | 69.3 ± 9.2 | 70.3 ± 10.4 | 73.6 ± 11.1 | 73.2 ± 10.4 | 70.9 ± 12.3 | 71.6 ± 10.0 | 69.7 ± 10.0 | 70.6 ± 8.9 |

### Confusion matrix, dual-branch, pooled protocol, Dataset 2b (seed 0 test partition, n = 1304)

| Actual \ Pred. | Left hand | Right hand |
|---|---|---|
| Left hand | 514 | 138 |
| Right hand | 245 | 407 |

### Class-wise performance, dual-branch, pooled, Dataset 2b (seed 0 test partition)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Left hand | 0.677 | 0.788 | 0.729 | 652 |
| Right hand | 0.747 | 0.624 | 0.680 | 652 |

### Confusion matrix, dual-branch, pooled protocol, Dataset 2b (summed over 5 seeds, n = 6520)

| Actual \ Pred. | Left hand | Right hand |
|---|---|---|
| Left hand | 2325 | 935 |
| Right hand | 957 | 2303 |

### Class-wise performance, dual-branch, pooled, Dataset 2b (summed over 5 seeds)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Left hand | 0.708 | 0.713 | 0.711 | 3260 |
| Right hand | 0.711 | 0.706 | 0.709 | 3260 |

### Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5) — per-subject accuracy (%), Dataset 2a

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | CNN (ShallowConvNet) | LSTM | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 57.2 | 32.4 | 71.1 | 73.3 | 61.8 | 47.9 | 73.3 | 70.6 | 74.7 |
| S2 | 34.6 | 25.1 | 44.6 | 24.7 | 25.3 | 28.1 | 45.7 | 40.3 | 44.1 |
| S3 | 65.9 | 29.4 | 76.9 | 70.8 | 74.7 | 55.2 | 81.2 | 81.6 | 84.0 |
| S4 | 45.6 | 31.2 | 55.2 | 43.4 | 48.6 | 27.4 | 55.9 | 60.1 | 54.9 |
| S5 | 42.9 | 24.9 | 52.5 | 22.9 | 25.3 | 25.3 | 52.3 | 50.2 | 55.6 |
| S6 | 34.4 | 27.7 | 38.8 | 26.0 | 26.4 | 27.4 | 39.4 | 39.7 | 40.3 |
| S7 | 56.6 | 27.9 | 75.3 | 60.1 | 25.7 | 26.4 | 77.9 | 76.3 | 79.2 |
| S8 | 66.3 | 35.8 | 78.1 | 76.4 | 68.8 | 57.6 | 78.1 | 77.7 | 79.9 |
| S9 | 64.9 | 40.0 | 78.8 | 79.2 | 59.0 | 51.0 | 80.1 | 81.5 | 81.9 |
| Mean ± SD | 52.0 ± 13.0 | 30.5 ± 5.0 | 63.5 ± 15.7 | 53.0 ± 23.8 | 46.2 ± 20.7 | 38.5 ± 14.0 | 64.9 ± 16.5 | 64.2 ± 17.2 | 66.0 ± 17.3 |
| Mean kappa | 0.361 | 0.073 | 0.513 | 0.373 | 0.282 | 0.180 | 0.532 | 0.523 | 0.547 |
| seeds | 3 | 3 | 3 | 1 | 1 | 1 | 3 | 3 | 3 |

### Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5), Dataset 2a: dual-branch vs other models

| Compared model | Δ acc (dual − model) | subjects dual better | Wilcoxon p (n = 9) |
|---|---|---|---|
| Conv1D branch only (ablation) | +21.6 | 9/9 | 0.004 |
| FBCSP branch only (ablation) | -11.4 | 0/9 | 0.004 |
| EEGNet-8,2 (re-implemented) | -0.9 | 4/9 | 0.734 |
| CNN (ShallowConvNet) | +5.9 | 5/9 | 0.250 |
| LSTM | +13.5 | 9/9 | 0.004 |
| FBCSP + SVM (RBF) | -12.8 | 0/9 | 0.004 |
| FBCSP + k-NN | -12.2 | 0/9 | 0.004 |
| FBCSP + LDA | -14.0 | 0/9 | 0.004 |

Dual-branch, Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5), 2a: subject-mean accuracy per seed = 51.08, 52.01, 53.05 (SD across seeds 0.98)


### Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5) — per-subject accuracy (%), Dataset 2b

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | CNN (ShallowConvNet) | LSTM | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 63.8 | 56.6 | 69.7 | 73.8 | 69.7 | 62.5 | 70.6 | 71.7 | 69.1 |
| S2 | 49.8 | 49.6 | 51.5 | 51.1 | 58.6 | 43.2 | 51.5 | 53.2 | 55.0 |
| S3 | 56.0 | 54.1 | 51.8 | 57.5 | 52.8 | 49.1 | 52.3 | 50.5 | 53.4 |
| S4 | 94.8 | 95.9 | 95.8 | 97.2 | 94.7 | 92.2 | 96.5 | 94.5 | 96.2 |
| S5 | 79.6 | 57.0 | 82.7 | 83.8 | 78.1 | 58.8 | 84.6 | 81.4 | 84.1 |
| S6 | 73.0 | 58.3 | 72.9 | 83.1 | 79.4 | 70.3 | 79.0 | 76.5 | 77.8 |
| S7 | 74.1 | 70.7 | 75.6 | 80.9 | 80.0 | 78.8 | 74.5 | 75.7 | 75.9 |
| S8 | 88.0 | 87.8 | 86.9 | 90.3 | 90.0 | 86.9 | 88.1 | 83.4 | 89.1 |
| S9 | 80.4 | 71.5 | 80.6 | 83.4 | 81.2 | 83.4 | 84.4 | 81.9 | 83.4 |
| Mean ± SD | 73.3 ± 14.6 | 66.8 ± 16.0 | 74.2 ± 14.9 | 77.9 ± 14.9 | 76.1 ± 13.6 | 69.5 ± 17.2 | 75.7 ± 15.4 | 74.3 ± 14.2 | 76.0 ± 14.6 |
| Mean kappa | 0.465 | 0.337 | 0.484 | 0.558 | 0.521 | 0.389 | 0.514 | 0.486 | 0.520 |
| seeds | 3 | 3 | 3 | 1 | 1 | 1 | 3 | 3 | 3 |

### Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5), Dataset 2b: dual-branch vs other models

| Compared model | Δ acc (dual − model) | subjects dual better | Wilcoxon p (n = 9) |
|---|---|---|---|
| Conv1D branch only (ablation) | +6.4 | 8/9 | 0.020 |
| FBCSP branch only (ablation) | -0.9 | 3/9 | 0.301 |
| EEGNet-8,2 (re-implemented) | -4.6 | 0/9 | 0.004 |
| CNN (ShallowConvNet) | -2.8 | 3/9 | 0.121 |
| LSTM | +3.8 | 7/9 | 0.203 |
| FBCSP + SVM (RBF) | -2.4 | 1/9 | 0.039 |
| FBCSP + k-NN | -1.0 | 3/9 | 0.496 |
| FBCSP + LDA | -2.7 | 1/9 | 0.027 |

Dual-branch, Subject-specific cross-session (2a: T→E; 2b: sessions 1–3 → 4–5), 2b: subject-mean accuracy per seed = 73.87, 73.52, 72.42 (SD across seeds 0.76)


### Leave-one-subject-out — per-subject accuracy (%), Dataset 2a

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|
| S1 | 45.4 | 23.3 | 45.1 | 51.4 | 43.4 | 41.7 | 47.2 |
| S2 | 29.2 | 29.9 | 24.7 | 28.5 | 25.7 | 26.0 | 25.0 |
| S3 | 50.3 | 29.9 | 58.7 | 58.7 | 37.5 | 40.6 | 55.6 |
| S4 | 35.1 | 23.6 | 34.4 | 32.3 | 37.5 | 33.7 | 35.8 |
| S5 | 28.0 | 24.0 | 28.1 | 29.2 | 26.4 | 27.4 | 27.4 |
| S6 | 31.1 | 26.7 | 29.9 | 31.2 | 29.9 | 29.5 | 31.6 |
| S7 | 30.7 | 28.1 | 25.7 | 36.1 | 27.8 | 24.7 | 30.6 |
| S8 | 41.9 | 28.1 | 54.2 | 60.1 | 52.8 | 52.8 | 50.3 |
| S9 | 42.9 | 34.0 | 42.7 | 59.0 | 39.9 | 38.9 | 44.8 |
| Mean ± SD | 37.2 ± 8.1 | 27.5 ± 3.5 | 38.2 ± 12.6 | 42.9 ± 14.0 | 35.6 ± 9.1 | 35.0 ± 9.2 | 38.7 ± 11.0 |
| Mean kappa | 0.162 | 0.033 | 0.175 | 0.239 | 0.142 | 0.134 | 0.183 |
| seeds | 3 | 1 | 1 | 1 | 1 | 1 | 1 |

### Leave-one-subject-out, Dataset 2a: dual-branch vs other models

| Compared model | Δ acc (dual − model) | subjects dual better | Wilcoxon p (n = 9) |
|---|---|---|---|
| Conv1D branch only (ablation) | +9.7 | 8/9 | 0.008 |
| FBCSP branch only (ablation) | -1.0 | 6/9 | 0.652 |
| EEGNet-8,2 (re-implemented) | -5.8 | 2/9 | 0.055 |
| FBCSP + SVM (RBF) | +1.5 | 7/9 | 0.250 |
| FBCSP + k-NN | +2.1 | 8/9 | 0.129 |
| FBCSP + LDA | -1.5 | 3/9 | 0.203 |

Dual-branch, Leave-one-subject-out, 2a: subject-mean accuracy per seed = 37.11, 37.31, 37.11 (SD across seeds 0.11)


### Leave-one-subject-out — per-subject accuracy (%), Dataset 2b

| Subject | Dual-branch (FBCSP + Conv1D) | Conv1D branch only (ablation) | FBCSP branch only (ablation) | EEGNet-8,2 (re-implemented) | FBCSP + SVM (RBF) | FBCSP + k-NN | FBCSP + LDA |
|---|---|---|---|---|---|---|---|
| S1 | 67.8 | 63.6 | 67.6 | 69.3 | 66.7 | 64.2 | 69.6 |
| S2 | 59.2 | 58.7 | 57.2 | 61.5 | 56.8 | 57.1 | 57.6 |
| S3 | 56.1 | 56.2 | 56.7 | 54.3 | 52.5 | 54.9 | 54.4 |
| S4 | 82.6 | 87.4 | 81.5 | 81.9 | 81.8 | 80.7 | 80.7 |
| S5 | 70.4 | 63.1 | 69.3 | 70.5 | 71.6 | 68.9 | 71.2 |
| S6 | 70.4 | 68.3 | 76.1 | 74.3 | 75.7 | 71.5 | 74.0 |
| S7 | 68.0 | 71.2 | 68.5 | 75.3 | 68.6 | 67.1 | 66.1 |
| S8 | 69.4 | 74.1 | 68.3 | 73.4 | 68.0 | 69.2 | 70.7 |
| S9 | 77.6 | 70.7 | 77.4 | 76.7 | 77.5 | 77.1 | 77.2 |
| Mean ± SD | 69.0 ± 8.1 | 68.2 ± 9.4 | 69.2 ± 8.4 | 70.8 ± 8.4 | 68.8 ± 9.5 | 67.8 ± 8.4 | 69.1 ± 8.6 |
| Mean kappa | 0.381 | 0.363 | 0.383 | 0.416 | 0.376 | 0.357 | 0.381 |
| seeds | 3 | 1 | 1 | 1 | 1 | 1 | 1 |

### Leave-one-subject-out, Dataset 2b: dual-branch vs other models

| Compared model | Δ acc (dual − model) | subjects dual better | Wilcoxon p (n = 9) |
|---|---|---|---|
| Conv1D branch only (ablation) | +0.9 | 5/9 | 0.652 |
| FBCSP branch only (ablation) | -0.1 | 6/9 | 0.496 |
| EEGNet-8,2 (re-implemented) | -1.8 | 3/9 | 0.164 |
| FBCSP + SVM (RBF) | +0.2 | 6/9 | 0.496 |
| FBCSP + k-NN | +1.2 | 8/9 | 0.027 |
| FBCSP + LDA | -0.0 | 5/9 | 0.820 |

Dual-branch, Leave-one-subject-out, 2b: subject-mean accuracy per seed = 69.33, 69.70, 68.10 (SD across seeds 0.84)


### Noise stress test, pooled protocol, Dataset 2a (30 noise realisations per seed; mean ± SD over seeds)

| Model | Clean acc (%) | Noisy 5 dB acc (%) | Drop (pp) |
|---|---|---|---|
| Conv1D branch only (ablation) | 30.10 ± 2.96 | 27.84 ± 1.90 | 2.25 |
| FBCSP branch only (ablation) | 53.33 ± 2.17 | 34.64 ± 0.39 | 18.69 |
| Dual-branch (FBCSP + Conv1D) | 46.67 ± 0.79 | 32.87 ± 1.24 | 13.80 |

### Noise stress test, pooled protocol, Dataset 2b (30 noise realisations per seed; mean ± SD over seeds)

| Model | Clean acc (%) | Noisy 5 dB acc (%) | Drop (pp) |
|---|---|---|---|
| Conv1D branch only (ablation) | 69.45 ± 0.67 | 67.75 ± 1.24 | 1.70 |
| FBCSP branch only (ablation) | 70.48 ± 1.08 | 69.20 ± 0.81 | 1.27 |
| Dual-branch (FBCSP + Conv1D) | 70.98 ± 1.06 | 69.17 ± 0.89 | 1.81 |